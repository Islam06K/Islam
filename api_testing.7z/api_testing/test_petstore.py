# test_petstore.py
import requests
import pprint

BASE_URL = 'https://petstore.swagger.io/v2'

# 1. Создать питомца БЕЗ указания id
print("=== POST /pet (create without ID) ===")
new_pet = {
    "name": "Barsic",
    "photoUrls": ["https://example.com/cat.jpg"],
    "status": "available"
    # "id" НЕ указываем!
}
response = requests.post(f'{BASE_URL}/pet', json=new_pet)
print("Status:", response.status_code)

if response.ok:
    pet_data = response.json()
    pet_id = pet_data['id']  # ← Получаем ID, который выдал сервер
    print("Created pet ID:", pet_id)
    pprint.pprint(pet_data)

    # 2. Получить созданного питомца
    print(f"\n=== GET /pet/{pet_id} ===")
    resp = requests.get(f'{BASE_URL}/pet/{pet_id}')
    if resp.ok:
        pprint.pprint(resp.json())
    else:
        print("GET failed:", resp.json())

    # 3. Удалить
    print(f"\n=== DELETE /pet/{pet_id} ===")
    delete_resp = requests.delete(f'{BASE_URL}/pet/{pet_id}')
    print("Delete status:", delete_resp.status_code)
else:
    print("Error creating pet:", response.text)